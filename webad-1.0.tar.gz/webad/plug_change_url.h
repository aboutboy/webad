#ifndef __PLUG_CHANGE_URL_H__
#define __PLUG_CHANGE_URL_H__

int init_change_url();

#endif 

