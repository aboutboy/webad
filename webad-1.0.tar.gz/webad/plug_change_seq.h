#ifndef __PLUG_CHANGE_SEQ_H__
#define __PLUG_CHANGE_SEQ_H__

int init_change_seq();

#endif 

