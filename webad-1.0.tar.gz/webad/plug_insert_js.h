#ifndef __PLUG_INSERT_JS_H__
#define __PLUG_INSERT_JS_H__

int init_insert_js();

#endif 

