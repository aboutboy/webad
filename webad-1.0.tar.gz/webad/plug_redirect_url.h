#ifndef __PLUG_REDIRECT_URL_H__
#define __PLUG_REDIRECT_URL_H__

int init_redirect_url();

#endif 

