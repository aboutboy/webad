#ifndef __PLUG_CHANGE_CHUNKED_HEX_H__
#define __PLUG_CHANGE_CHUNKED_HEX_H__

int init_change_chunked_hex();

#endif 

