#ifndef __QUEUE_H__
#define __QUEUE_H__

int set_queue(void *data , int dlen);

int get_queue(void *data);

int init_queue();


#endif

