#ifndef __PLUG_CHANGE_ACCEPT_ENCODING_H__
#define __PLUG_CHANGE_ACCEPT_ENCODING_H__

int init_change_accept_encoding();

#endif 

